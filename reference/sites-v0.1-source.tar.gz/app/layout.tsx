import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'GN Engine — Le Ludificateur',description:'Vos mondes prennent vie. Personnages, compétences et points de vie pour le jeu de rôle grandeur nature.',referrer:'no-referrer',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
