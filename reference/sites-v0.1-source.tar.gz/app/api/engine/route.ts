import { env } from 'cloudflare:workers';
import { CATALOGUE } from '../../../lib/catalogue';
import { DEFAULT_CONFIG, config, integer, string, skill, damage, assertUse, applySkill, fixtureEffect, type Skill } from '../../../lib/rules';
export const dynamic='force-dynamic';
type Row=Record<string,any>;
const id=()=>crypto.randomUUID();
const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});
const parse=(s:string)=>JSON.parse(s);
const db=()=>{if(!env.DB)throw new Error('Base de données indisponible.');return env.DB;};
const first=async(sql:string,...args:any[])=>await db().prepare(sql).bind(...args).first<Row>();
const all=async(sql:string,...args:any[])=>((await db().prepare(sql).bind(...args).all<Row>()).results??[]);
function owner(req:Request){const u=req.headers.get('oai-authenticated-user-id');if(!u)throw new Error('AUTH_REQUIRED');return u;}
async function session(req:Request,sid:string){const s=await first('SELECT * FROM sessions WHERE id=? AND owner=?',sid,owner(req));if(!s)throw new Error('Partie introuvable.');return s;}
async function access(req:Request){const key=req.headers.get('authorization')?.replace(/^Bearer /,'');if(!key||key.length>200)throw new Error('Accès joueur invalide.');const p=await first('SELECT * FROM players WHERE access_key=?',key);if(!p)throw new Error('Accès joueur invalide.');const s=await first('SELECT * FROM sessions WHERE id=?',p.session_id);if(!s)throw new Error('Partie introuvable.');return {p,s};}
const cleanSession=(s:Row)=>({id:s.id,name:s.name,description:s.description,status:s.status,config:parse(s.config),skills:parse(s.skills),createdAt:s.created_at,version:s.version});
const cleanPlayer=(p:Row,gm=false)=>({id:p.id,sessionId:p.session_id,name:p.name,role:p.role,faction:p.faction,biography:p.biography,objectives:p.objectives,...(gm?{}:{notes:p.notes}),hp:p.hp,maxHp:p.max_hp,states:parse(p.states),skills:parse(p.skills),inventory:parse(p.inventory),publicCode:p.public_code,version:p.version,...(gm?{accessKey:p.access_key}:{})});
async function library(user:string){return [...CATALOGUE,...(await all('SELECT data FROM skills WHERE owner=? ORDER BY created_at',user)).map(x=>parse(x.data))];}
function event(sid:string,actor:string|null,target:string|null,kind:string,label:string,detail='',eventId=id()){return {id:eventId,sessionId:sid,actorId:actor,targetId:target,kind,label,detail,createdAt:Date.now()};}
function eventStmt(e:any){return db().prepare('INSERT INTO events(id,session_id,actor_id,target_id,kind,label,detail,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(e.id,e.sessionId,e.actorId,e.targetId,e.kind,e.label,e.detail,e.createdAt);}
const playerGuard=(p:Row)=>({sql:'EXISTS(SELECT 1 FROM players WHERE id=? AND version=?)',args:[p.id,p.version]});
const sessionGuard=(s:Row)=>({sql:'EXISTS(SELECT 1 FROM sessions WHERE id=? AND version=?)',args:[s.id,s.version]});
async function transaction(e:any,guards:{sql:string,args:any[]}[],statements:D1PreparedStatement[]){
 const seen=await first('SELECT * FROM events WHERE id=? AND session_id=? AND actor_id IS ?',e.id,e.sessionId,e.actorId);if(seen)return {ok:true,replayed:true};
 const guardId=id();const g=db().prepare(`INSERT INTO operation_guards(id,valid) SELECT ?,CASE WHEN ${guards.map(g=>`(${g.sql})`).join(' AND ')||'1'} THEN 1 ELSE 0 END`).bind(guardId,...guards.flatMap(g=>g.args));
 try{await db().batch([g,...statements,eventStmt(e),db().prepare('DELETE FROM operation_guards WHERE id=?').bind(guardId)]);}catch(err){const replay=await first('SELECT id FROM events WHERE id=? AND session_id=? AND actor_id IS ?',e.id,e.sessionId,e.actorId);if(replay)return {ok:true,replayed:true};if(String(err).includes('guard_valid'))throw new Error('La situation vient de changer. Actualisez la fiche puis recommencez.');throw err;}
 return {ok:true};
}
function running(s:Row){if(s.status!=='EN_JEU')throw new Error('Cette partie n’est pas en cours.');}
function reqId(b:any){const key=string(b.requestId,80,true);if(!/^[a-zA-Z0-9-]{10,80}$/.test(key))throw new Error('Identifiant d’action invalide.');return key;}
function selectedSkills(s:Row,ids:any){if(!Array.isArray(ids))return [];const allowed=new Set(parse(s.skills).map((x:Skill)=>x.id));if(ids.some(x=>!allowed.has(x)))throw new Error('Compétence absente de cette partie.');return [...new Set(ids)].slice(0,200);}
function listStrings(a:any,max=100){if(!Array.isArray(a)||a.length>max)throw new Error('Liste invalide.');return a.map(x=>string(x,120,true));}
function inventory(a:any){if(!Array.isArray(a)||a.length>500)throw new Error('Inventaire invalide.');return a.map(x=>({id:x.id?string(x.id,100,true):id(),name:string(x.name,120,true),description:string(x.description,2000),quantity:integer(x.quantity??1,1,9999)}));}
async function get(req:Request){
 const url=new URL(req.url);const mode=url.searchParams.get('mode')??'bootstrap';
 if(mode==='history'){const {p,s}=await access(req);const before=integer(url.searchParams.get('before')??Date.now()+1,0,Number.MAX_SAFE_INTEGER);const last=string(url.searchParams.get('last')??'~',100);return {events:await all("SELECT * FROM events WHERE session_id=? AND (actor_id=? OR target_id=? OR kind IN ('ANNOUNCEMENT','POLL')) AND (created_at<? OR (created_at=? AND id<?)) ORDER BY created_at DESC,id DESC LIMIT 50",s.id,p.id,p.id,before,before,last)};}
 if(mode==='player'){
  const {p,s}=await access(req);const ev=await all("SELECT * FROM events WHERE session_id=? AND (actor_id=? OR target_id=? OR kind IN ('ANNOUNCEMENT','POLL')) ORDER BY created_at DESC,id DESC LIMIT 50",s.id,p.id,p.id);
  const pp=await all("SELECT p.*,b.choice FROM polls p LEFT JOIN ballots b ON b.poll_id=p.id AND b.player_id=? WHERE p.session_id=? AND p.status='OPEN' ORDER BY created_at DESC",p.id,s.id);
  return {player:cleanPlayer(p),session:cleanSession(s),events:ev,polls:pp.map(x=>({...x,options:parse(x.options)})),uses:await all('SELECT * FROM uses WHERE player_id=?',p.id),pending:await all("SELECT * FROM pending WHERE actor_id=? AND status='PENDING' ORDER BY created_at DESC LIMIT 50",p.id)};
 }
 const u=owner(req);
 if(mode==='bootstrap')return {sessions:await all('SELECT s.*, (SELECT COUNT(*) FROM players p WHERE p.session_id=s.id) AS playerCount FROM sessions s WHERE owner=? ORDER BY created_at DESC',u),skills:await library(u),defaults:DEFAULT_CONFIG};
 const s=await session(req,string(url.searchParams.get('session'),100,true));
 if(mode==='fixtures'){const page=integer(url.searchParams.get('page')??0,0,Math.floor(Number.MAX_SAFE_INTEGER/50));return {fixtures:await all('SELECT * FROM fixtures WHERE session_id=? ORDER BY name,id LIMIT 50 OFFSET ?',s.id,page*50),total:(await first('SELECT COUNT(*) AS total FROM fixtures WHERE session_id=?',s.id))?.total??0};}
 if(mode==='session'){
  const page=integer(url.searchParams.get('page')??0,0,Math.floor(Number.MAX_SAFE_INTEGER/50));const q=string(url.searchParams.get('q'),100);const search=`%${q.replace(/[\\%_]/g,'\\$&')}%`;const filter="session_id=? AND (name LIKE ? ESCAPE '\\' OR faction LIKE ? ESCAPE '\\' OR role LIKE ? ESCAPE '\\')";
  const [ps,counts,filtered,ev,pn,pp]=await Promise.all([all(`SELECT * FROM players WHERE ${filter} ORDER BY name,id LIMIT 50 OFFSET ?`,s.id,search,search,search,page*50),first('SELECT COUNT(*) AS total, SUM(CASE WHEN hp=0 THEN 1 ELSE 0 END) AS down,SUM(CASE WHEN hp>0 AND hp<max_hp THEN 1 ELSE 0 END) AS wounded FROM players WHERE session_id=?',s.id),first(`SELECT COUNT(*) AS total FROM players WHERE ${filter}`,s.id,search,search,search),all('SELECT * FROM events WHERE session_id=? ORDER BY created_at DESC,id DESC LIMIT 60',s.id),all("SELECT q.*,p.name AS actor_name,t.name AS target_name FROM pending q JOIN players p ON q.actor_id=p.id LEFT JOIN players t ON q.target_id=t.id WHERE q.session_id=? AND q.status='PENDING' ORDER BY q.created_at LIMIT 100",s.id),all('SELECT p.*, (SELECT COUNT(*) FROM ballots b WHERE b.poll_id=p.id) AS total FROM polls p WHERE session_id=? ORDER BY created_at DESC',s.id)]);
  const tallies=await all('SELECT b.poll_id,b.choice,COUNT(*) AS count FROM ballots b JOIN polls p ON b.poll_id=p.id WHERE p.session_id=? GROUP BY b.poll_id,b.choice',s.id);
  return {session:cleanSession(s),players:ps.map(p=>cleanPlayer(p,true)),counts,filtered:filtered?.total??0,events:ev,pending:pn,polls:pp.map(x=>({...x,options:parse(x.options),tallies:tallies.filter(t=>t.poll_id===x.id)}))};
 }
 if(mode==='export')return {format:'gn-engine-session-v1',session:cleanSession(s),players:(await all('SELECT * FROM players WHERE session_id=? ORDER BY name,id LIMIT 50 OFFSET ?',s.id,integer(url.searchParams.get('page')??0,0,Math.floor(Number.MAX_SAFE_INTEGER/50))*50)).map(p=>({...cleanPlayer(p),notes:undefined}))};
 throw new Error('Vue inconnue.');
}
async function post(req:Request){
 const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)throw new Error('Origine invalide.');
 const raw=await req.text();if(raw.length>500000)throw new Error('Envoi trop volumineux.');const b=JSON.parse(raw);const action=b.action;
 if(['damage','use','notes','transfer','vote','resolve'].includes(action)){
  const {p,s}=await access(req);
  if(action==='resolve'){
   if(b.targetType==='FIXTURE'){
    const t=await first('SELECT * FROM fixtures WHERE session_id=? AND public_code=?',s.id,string(b.code,100,true));if(!t)throw new Error('QR de lieu ou d’objet inconnu dans cette partie.');
    const reveal=t.kind==='LOCK'&&t.state==='OPEN'?t.reveal:'';
    if(reveal){const known=await first("SELECT id FROM events WHERE session_id=? AND actor_id=? AND target_id=? AND kind='CLUE' LIMIT 1",s.id,p.id,t.id);if(!known)await transaction(event(s.id,p.id,t.id,'CLUE',`Découverte · ${t.name}`,reveal,reqId(b)),[sessionGuard(s),{sql:'EXISTS(SELECT 1 FROM fixtures WHERE id=? AND version=?)',args:[t.id,t.version]}],[]);}
    return {target:{id:t.id,name:t.name,kind:t.kind,state:t.state,scene:t.scene,reveal,public_code:t.public_code}};
   }
   const t=await first('SELECT id,name,role,public_code FROM players WHERE session_id=? AND public_code=?',s.id,string(b.code,100,true));if(!t)throw new Error('QR inconnu dans cette partie.');return {target:t};
  }
  if(action==='notes'){await db().prepare('UPDATE players SET notes=? WHERE id=?').bind(string(b.notes,30000),p.id).run();return {ok:true};}
  running(s);const rid=reqId(b);const seen=await first('SELECT id FROM events WHERE id=? AND session_id=? AND actor_id=?',rid,s.id,p.id);if(seen)return {ok:true,replayed:true};
  if(action==='damage'){
   const cfg=parse(s.config);if(!cfg.allowSelfReport)throw new Error('Les blessures sont saisies par le MJ pour cette partie.');const hit=damage(p.hp,integer(b.foam,0,999),integer(b.gel,0,999),cfg);if(p.hp===0)throw new Error('Vous êtes déjà hors combat.');const e=event(s.id,p.id,p.id,'DAMAGE',`${p.name} · ${hit.applied} PV perdu${hit.applied>1?'s':''}`,`${b.foam} touche(s) mousse · ${b.gel} touche(s) gel. PV : ${p.hp} → ${hit.after}.`,rid);
   return transaction(e,[sessionGuard(s),playerGuard(p)],[db().prepare('UPDATE players SET hp=?,version=version+1 WHERE id=?').bind(hit.after,p.id)]);
  }
  if(action==='vote'){
   const poll=await first("SELECT * FROM polls WHERE id=? AND session_id=? AND status='OPEN'",b.pollId,s.id);if(!poll)throw new Error('Vote fermé ou introuvable.');const choice=integer(b.choice,0,parse(poll.options).length-1);const previous=await first('SELECT id FROM ballots WHERE poll_id=? AND player_id=?',poll.id,p.id);if(previous)throw new Error('Votre vote a déjà été enregistré.');
   return transaction(event(s.id,p.id,p.id,'BALLOT','Vote enregistré',poll.question,rid),[sessionGuard(s),{sql:"EXISTS(SELECT 1 FROM polls WHERE id=? AND status='OPEN')",args:[poll.id]}],[db().prepare('INSERT INTO ballots(id,poll_id,player_id,choice) VALUES(?,?,?,?)').bind(id(),poll.id,p.id,choice)]);
  }
  if(action==='transfer'){
   if(p.hp===0)throw new Error('Vous êtes hors combat.');const t=await first('SELECT * FROM players WHERE public_code=? AND session_id=?',string(b.code,100,true),s.id);if(!t||t.id===p.id)throw new Error('Destinataire invalide.');const own=inventory(parse(p.inventory));const pos=own.findIndex((x:any)=>x.id===b.objectId);if(pos<0)throw new Error('Objet absent du sac.');const obj=own[pos];const qty=integer(b.quantity,1,obj.quantity);const moved={...obj,id:id(),quantity:qty};obj.quantity-=qty;if(!obj.quantity)own.splice(pos,1);const ti=inventory(parse(t.inventory));ti.push(moved);if(ti.length>500)throw new Error('Le sac du destinataire contient trop de lignes d’objets.');
   return transaction(event(s.id,p.id,t.id,'TRANSFER',`${p.name} remet ${qty} × ${obj.name} à ${t.name}`,'',rid),[sessionGuard(s),playerGuard(p),playerGuard(t)],[db().prepare('UPDATE players SET inventory=?,version=version+1 WHERE id=?').bind(JSON.stringify(own),p.id),db().prepare('UPDATE players SET inventory=?,version=version+1 WHERE id=?').bind(JSON.stringify(ti),t.id)]);
  }
  const sk:Skill|undefined=parse(s.skills).find((x:Skill)=>x.id===b.skillId);if(!sk||!parse(p.skills).includes(sk.id))throw new Error('Compétence non attribuée.');const usage=await first('SELECT * FROM uses WHERE player_id=? AND skill_id=?',p.id,sk.id);assertUse(sk,p,usage,Date.now());if(b.sceneDone!==true)throw new Error('Confirmez que la scène de jeu a été réalisée.');
  if(sk.target==='FIXTURE'){
   const t=await first('SELECT * FROM fixtures WHERE session_id=? AND public_code=?',s.id,string(b.code,100,true));if(!t)throw new Error('QR de lieu ou d’objet inconnu.');const state=fixtureEffect(sk,t);const revealed=state==='OPEN'&&t.reveal;
   return transaction(event(s.id,p.id,t.id,revealed?'CLUE':'FIXTURE',`${sk.name} · ${t.name}`,revealed||`${t.name} : ${state==='OPEN'?'ouvert':state==='DISABLED'?'hors service':'en service'}.`,rid),[sessionGuard(s),playerGuard(p),{sql:'EXISTS(SELECT 1 FROM fixtures WHERE id=? AND version=?)',args:[t.id,t.version]}],[db().prepare('UPDATE fixtures SET state=?,version=version+1 WHERE id=?').bind(state,t.id),db().prepare('UPDATE players SET version=version+1 WHERE id=?').bind(p.id),db().prepare('INSERT INTO uses(session_id,player_id,skill_id,count,last_at) VALUES(?,?,?,1,?) ON CONFLICT(session_id,player_id,skill_id) DO UPDATE SET count=count+1,last_at=excluded.last_at').bind(s.id,p.id,sk.id,Date.now())]);
  }
  const t=sk.target==='SELF'?p:sk.target==='FREE'?null:await first('SELECT * FROM players WHERE session_id=? AND public_code=?',s.id,string(b.code,100,true));if(sk.target==='CHARACTER'&&!t)throw new Error('QR de cible inconnu.');if(sk.target==='CHARACTER'&&t!.id===p.id)throw new Error('Cette compétence demande un autre personnage.');
  const e=event(s.id,p.id,t?.id??null,sk.effect==='ARBITRATION'?'REQUEST':'SKILL',`${p.name} · ${sk.name}`,sk.effect==='ARBITRATION'?'Demande transmise au MJ.':`Cible : ${t?.name}.`,rid);
  const guards=[sessionGuard(s),playerGuard(p),...(t&&t.id!==p.id?[playerGuard(t)]:[])];
  if(sk.effect==='ARBITRATION'){
   const already=await first("SELECT id FROM pending WHERE actor_id=? AND skill_id=? AND status='PENDING'",p.id,sk.id);if(already)throw new Error('Une demande pour cette compétence attend déjà le MJ.');
   return transaction(e,guards,[db().prepare('INSERT INTO pending(id,session_id,actor_id,target_id,skill_id,note,created_at) VALUES(?,?,?,?,?,?,?)').bind(rid,s.id,p.id,t?.id??null,sk.id,string(b.note,2000,true),Date.now()),db().prepare('UPDATE players SET version=version+1 WHERE id=?').bind(p.id)]);
  }
  const result=applySkill(sk,t!);e.detail=`${t!.name} : ${t!.hp} → ${result.hp} PV.${sk.effect==='CURE'?` État retiré : ${sk.state}.`:''}`;
  const writes=[db().prepare('UPDATE players SET hp=?,states=?,version=version+1 WHERE id=?').bind(result.hp,JSON.stringify(result.states),t!.id)];if(t!.id!==p.id)writes.push(db().prepare('UPDATE players SET version=version+1 WHERE id=?').bind(p.id));
  writes.push(db().prepare('INSERT INTO uses(session_id,player_id,skill_id,count,last_at) VALUES(?,?,?,1,?) ON CONFLICT(session_id,player_id,skill_id) DO UPDATE SET count=count+1,last_at=excluded.last_at').bind(s.id,p.id,sk.id,Date.now()));return transaction(e,guards,writes);
 }
 const u=owner(req);
 if(action==='create_skill'){const sk=skill(b.skill,id());await db().prepare('INSERT INTO skills(id,owner,data,created_at) VALUES(?,?,?,?)').bind(sk.id,u,JSON.stringify(sk),Date.now()).run();return {ok:true,skill:sk};}
 if(action==='create_session'){
  const sid=reqId(b);const current=await first('SELECT id FROM sessions WHERE id=? AND owner=?',sid,u);if(current)return {ok:true,id:sid};const cfg=config(b.config??DEFAULT_CONFIG);const available=await library(u);const ids=new Set(listStrings(b.skillIds??available.map(x=>x.id),200));const chosen=available.filter(x=>ids.has(x.id));if(chosen.length!==ids.size)throw new Error('Compétence inconnue.');
  await db().batch([db().prepare('INSERT INTO sessions(id,owner,name,description,status,config,skills,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(sid,u,string(b.name,150,true),string(b.description,6000),'PREPARATION',JSON.stringify(cfg),JSON.stringify(chosen),Date.now()),eventStmt(event(sid,u,null,'SESSION','Partie créée'))]);return {ok:true,id:sid};
 }
 const s=await session(req,string(b.sessionId,100,true));const rid=reqId(b);
 if(action==='save_fixture'){
  const old=b.fixtureId?await first('SELECT * FROM fixtures WHERE id=? AND session_id=?',b.fixtureId,s.id):null;if(b.fixtureId&&!old)throw new Error('Élément QR introuvable.');if(old&&Number(b.version)!==old.version)throw new Error('L’élément a changé. Actualisez avant de modifier.');
  const kind=old?.kind??(b.kind==='EQUIPMENT'?'EQUIPMENT':'LOCK');const allowed=kind==='LOCK'?['LOCKED','OPEN']:['WORKING','DISABLED'];const state=allowed.includes(b.state)?b.state:allowed[0];const fid=old?.id??id();const args=[string(b.name,150,true),string(b.scene,3000,true),string(b.reveal,6000),state];
  const write=old?db().prepare('UPDATE fixtures SET name=?,scene=?,reveal=?,state=?,version=version+1 WHERE id=?').bind(...args,fid):db().prepare('INSERT INTO fixtures(id,session_id,name,kind,state,scene,reveal,public_code,created_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(fid,s.id,args[0],kind,state,args[1],args[2],id(),Date.now());
  return transaction(event(s.id,u,null,'GM',`${old?'Élément QR modifié':'Élément QR créé'} · ${args[0]}`,'',rid),[sessionGuard(s),...(old?[{sql:'EXISTS(SELECT 1 FROM fixtures WHERE id=? AND version=?)',args:[fid,old.version]}]:[])],[write]);
 }
 if(action==='session_status'){
  if(!['PREPARATION','EN_JEU','PAUSE','TERMINEE'].includes(b.status))throw new Error('Statut invalide.');return transaction(event(s.id,u,null,'SESSION',`Partie : ${b.status}`,'',rid),[sessionGuard(s)],[db().prepare('UPDATE sessions SET status=?,version=version+1 WHERE id=?').bind(b.status,s.id)]);
 }
 if(action==='session_config'){
  if(s.status==='EN_JEU')throw new Error('Mettez la partie en pause avant de modifier ses règles.');const cfg=config(b.config);return transaction(event(s.id,u,null,'CONFIG','Règles mises à jour','',rid),[sessionGuard(s)],[db().prepare('UPDATE sessions SET config=?,name=?,description=?,version=version+1 WHERE id=?').bind(JSON.stringify(cfg),string(b.name,150,true),string(b.description,6000),s.id)]);
 }
 if(action==='session_skill'){
  if(s.status==='EN_JEU')throw new Error('Mettez la partie en pause avant de modifier une compétence.');const sk=(await library(u)).find(x=>x.id===b.skillId);if(!sk)throw new Error('Compétence inconnue.');const list:Skill[]=parse(s.skills);const i=list.findIndex(x=>x.id===sk.id);if(i<0)list.push(sk);else list[i]=sk;
  return transaction(event(s.id,u,null,'CONFIG',`Compétence disponible : ${sk.name}`,'',rid),[sessionGuard(s)],[db().prepare('UPDATE sessions SET skills=?,version=version+1 WHERE id=?').bind(JSON.stringify(list),s.id)]);
 }
 if(action==='create_players'){
  if(!Array.isArray(b.players)||!b.players.length||b.players.length>50)throw new Error('Envoyez de 1 à 50 personnages par lot. Vous pouvez envoyer autant de lots que nécessaire.');const writes:D1PreparedStatement[]=[];
  for(const input of b.players){const maxHp=integer(input.maxHp??parse(s.config).defaultHp,1,999);writes.push(db().prepare('INSERT INTO players(id,session_id,name,role,faction,biography,objectives,hp,max_hp,skills,inventory,access_key,public_code,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id(),s.id,string(input.name,120,true),string(input.role,120),string(input.faction,120),string(input.biography,12000),string(input.objectives,6000),maxHp,maxHp,JSON.stringify(selectedSkills(s,input.skills??[])),JSON.stringify(inventory(input.inventory??[])),id()+id(),id(),Date.now()));}
  return transaction(event(s.id,u,null,'ROSTER',`${b.players.length} personnage(s) ajouté(s)`,'',rid),[sessionGuard(s)],writes);
 }
 if(action==='update_player'){
  const p=await first('SELECT * FROM players WHERE id=? AND session_id=?',b.playerId,s.id);if(!p)throw new Error('Personnage introuvable.');if(Number(b.version)!==p.version)throw new Error('La fiche a changé. Actualisez avant de modifier.');const hp=integer(b.hp,0,999);const maxHp=integer(b.maxHp,1,999);if(hp>maxHp)throw new Error('Les PV ne peuvent pas dépasser le maximum.');
  return transaction(event(s.id,u,p.id,'GM',`Fiche de ${p.name} mise à jour par le MJ`,string(b.reason,1000,true),rid),[sessionGuard(s),playerGuard(p)],[db().prepare('UPDATE players SET name=?,role=?,faction=?,biography=?,objectives=?,hp=?,max_hp=?,states=?,skills=?,inventory=?,version=version+1 WHERE id=?').bind(string(b.name,120,true),string(b.role,120),string(b.faction,120),string(b.biography,12000),string(b.objectives,6000),hp,maxHp,JSON.stringify(listStrings(b.states??[],50)),JSON.stringify(selectedSkills(s,b.skills??[])),JSON.stringify(inventory(b.inventory??[])),p.id)]);
 }
 if(action==='rotate_access'){const p=await first('SELECT * FROM players WHERE id=? AND session_id=?',b.playerId,s.id);if(!p)throw new Error('Personnage introuvable.');return transaction(event(s.id,u,p.id,'GM','Accès joueur renouvelé','Les anciens liens privés ne fonctionnent plus.',rid),[playerGuard(p)],[db().prepare('UPDATE players SET access_key=?,version=version+1 WHERE id=?').bind(id()+id(),p.id)]);}
 if(action==='announcement')return transaction(event(s.id,u,null,'ANNOUNCEMENT',string(b.title,150,true),string(b.text,6000,true),rid),[],[]);
 if(action==='clue'){
  const p=await first('SELECT id FROM players WHERE id=? AND session_id=?',b.playerId,s.id);if(!p)throw new Error('Destinataire introuvable.');return transaction(event(s.id,u,p.id,'CLUE',string(b.title,150,true),string(b.text,10000,true),rid),[],[]);
 }
 if(action==='arbitrate'){
  const q=await first("SELECT * FROM pending WHERE id=? AND session_id=? AND status='PENDING'",b.pendingId,s.id);if(!q)throw new Error('Demande déjà traitée ou introuvable.');const p=await first('SELECT * FROM players WHERE id=?',q.actor_id);if(!p)throw new Error('Personnage absent.');const sk:Skill=parse(s.skills).find((x:Skill)=>x.id===q.skill_id);if(!sk)throw new Error('Compétence absente.');const approved=b.approved===true;const note=string(b.note,3000,true);const writes=[db().prepare('UPDATE pending SET status=? WHERE id=?').bind(approved?'APPROVED':'REJECTED',q.id),db().prepare('UPDATE players SET version=version+1 WHERE id=?').bind(p.id)];
  if(approved){const usage=await first('SELECT * FROM uses WHERE player_id=? AND skill_id=?',p.id,sk.id);assertUse(sk,p,usage,Date.now());writes.push(db().prepare('INSERT INTO uses(session_id,player_id,skill_id,count,last_at) VALUES(?,?,?,1,?) ON CONFLICT(session_id,player_id,skill_id) DO UPDATE SET count=count+1,last_at=excluded.last_at').bind(s.id,p.id,sk.id,Date.now()));}
  return transaction(event(s.id,u,p.id,'ARBITRATION',`${sk.name} · ${approved?'validée':'refusée'}`,note,rid),[sessionGuard(s),playerGuard(p),{sql:"EXISTS(SELECT 1 FROM pending WHERE id=? AND status='PENDING')",args:[q.id]}],writes);
 }
 if(action==='create_poll'){const options=listStrings(b.options,20);if(options.length<2||new Set(options).size!==options.length)throw new Error('Il faut au moins deux choix distincts.');const pid=id();return transaction(event(s.id,u,null,'POLL',`Nouveau vote : ${string(b.question,300,true)}`,'',rid),[],[db().prepare('INSERT INTO polls(id,session_id,question,options,created_at) VALUES(?,?,?,?,?)').bind(pid,s.id,string(b.question,300,true),JSON.stringify(options),Date.now())]);}
 if(action==='close_poll')return transaction(event(s.id,u,null,'GM','Vote clôturé','',rid),[],[db().prepare("UPDATE polls SET status='CLOSED' WHERE id=? AND session_id=?").bind(string(b.pollId,100,true),s.id)]);
 throw new Error('Action inconnue.');
}
export async function GET(req:Request){try{return json(await get(req));}catch(e){const m=e instanceof Error?e.message:'Erreur inattendue.';return json({error:m},m==='AUTH_REQUIRED'?401:400);}}
export async function POST(req:Request){try{return json(await post(req));}catch(e){const m=e instanceof Error?e.message:'Erreur inattendue.';if(/D1_|SQLITE_|constraint|syntax error/i.test(m)){console.error('GN Engine database operation failed',m);return json({error:'L’action n’a pas été enregistrée. Actualisez et réessayez.'},409);}return json({error:m},m==='AUTH_REQUIRED'?401:400);}}
