import Engine from './engine';
export const dynamic='force-dynamic';
export default function Page(){return <Engine/>}
