CREATE TABLE `fixtures` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`name` text NOT NULL,
	`kind` text NOT NULL,
	`state` text NOT NULL,
	`scene` text DEFAULT '' NOT NULL,
	`reveal` text DEFAULT '' NOT NULL,
	`public_code` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`session_id`) REFERENCES `sessions`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `fixtures_code` ON `fixtures` (`public_code`);--> statement-breakpoint
CREATE INDEX `fixtures_session` ON `fixtures` (`session_id`,`name`);