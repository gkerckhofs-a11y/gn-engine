CREATE TABLE `ballots` (
	`id` text PRIMARY KEY NOT NULL,
	`poll_id` text NOT NULL,
	`player_id` text NOT NULL,
	`choice` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `ballots_once` ON `ballots` (`poll_id`,`player_id`);--> statement-breakpoint
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`actor_id` text,
	`target_id` text,
	`kind` text NOT NULL,
	`label` text NOT NULL,
	`detail` text DEFAULT '' NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`session_id`) REFERENCES `sessions`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `events_session_time` ON `events` (`session_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `events_actor` ON `events` (`actor_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `events_target` ON `events` (`target_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `operation_guards` (
	`id` text PRIMARY KEY NOT NULL,
	`valid` integer NOT NULL,
	CONSTRAINT "guard_valid" CHECK("operation_guards"."valid"=1)
);
--> statement-breakpoint
CREATE TABLE `pending` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`actor_id` text NOT NULL,
	`target_id` text,
	`skill_id` text NOT NULL,
	`note` text NOT NULL,
	`status` text DEFAULT 'PENDING' NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `pending_session` ON `pending` (`session_id`,`status`);--> statement-breakpoint
CREATE TABLE `players` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`name` text NOT NULL,
	`role` text DEFAULT '' NOT NULL,
	`faction` text DEFAULT '' NOT NULL,
	`biography` text DEFAULT '' NOT NULL,
	`objectives` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`hp` integer NOT NULL,
	`max_hp` integer NOT NULL,
	`states` text DEFAULT '[]' NOT NULL,
	`skills` text DEFAULT '[]' NOT NULL,
	`inventory` text DEFAULT '[]' NOT NULL,
	`access_key` text NOT NULL,
	`public_code` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`session_id`) REFERENCES `sessions`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "valid_hp" CHECK("players"."hp" >= 0 AND "players"."hp" <= "players"."max_hp" AND "players"."max_hp" > 0)
);
--> statement-breakpoint
CREATE INDEX `players_session_name` ON `players` (`session_id`,`name`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `players_access_key` ON `players` (`access_key`);--> statement-breakpoint
CREATE UNIQUE INDEX `players_public_code` ON `players` (`public_code`);--> statement-breakpoint
CREATE TABLE `polls` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`question` text NOT NULL,
	`options` text NOT NULL,
	`status` text DEFAULT 'OPEN' NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `polls_session` ON `polls` (`session_id`);--> statement-breakpoint
CREATE TABLE `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'PREPARATION' NOT NULL,
	`config` text NOT NULL,
	`skills` text NOT NULL,
	`created_at` integer NOT NULL,
	`version` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `sessions_owner` ON `sessions` (`owner`);--> statement-breakpoint
CREATE TABLE `skills` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`data` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `skills_owner` ON `skills` (`owner`);--> statement-breakpoint
CREATE TABLE `uses` (
	`session_id` text NOT NULL,
	`player_id` text NOT NULL,
	`skill_id` text NOT NULL,
	`count` integer NOT NULL,
	`last_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uses_once` ON `uses` (`session_id`,`player_id`,`skill_id`);