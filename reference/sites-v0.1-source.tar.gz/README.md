# GN Engine — V0.1

Version indépendante de préparation pour des jeux de rôle grandeur nature, créée le 18 octobre 2026 à partir du besoin de Guilz : combats physiques avec armes en mousse et gel blasters, effectifs extensibles, points de vie et bibliothèque de compétences.

## Périmètre livré

- Parties distinctes : préparation, en jeu, pause et terminée.
- Personnages individuels ou import en lots. Liste paginée, sans quota applicatif de participants.
- PV maximum par personnage ; blessures déclarées après combat ; coûts mousse et gel distincts par scénario. Les valeurs initiales (5 PV et 1 dégât par touche) sont des propositions modifiables.
- Zéro PV : personnage hors combat, actions de jeu bloquées jusqu’à un soin autorisé ou une correction MJ. Pas de mort automatique ni de chronomètre d’agonie.
- 20 compétences de départ et création de variantes. La définition est copiée dans chaque partie ; les modifications de bibliothèque ne changent pas une partie en cours.
- Soins et antidote avec QR public de personnage ; contrôle d’attribution, récupération et usages côté serveur.
- QR de lieux et d’objets : crochetage ouvre les verrous, sabotage désactive les équipements, réparation les réactive. Un coffre ouvert peut révéler un indice conservé dans les informations personnelles. L’application enregistre un état de jeu ; les effets sur les accessoires physiques suivent les règles de l’organisateur.
- Autres compétences : scène sur le terrain, demande MJ, arbitrage et consommation d’usage lors de la validation. Les conséquences d’objet ou d’état sont ensuite appliquées dans les fiches par le MJ.
- Inventaire et don entre personnages par QR, objectifs, histoire, notes privées, informations et indices, votes à choix unique avec confirmation.
- Journal, corrections MJ motivées, réinitialisation des états de QR, renouvellement des accès privés.

## Accès et intégrité

Le site est publié en accès propriétaire privé. Il permet la préparation et les tests par le propriétaire. Un événement accessible aux joueurs extérieurs demande un changement explicite d’audience, puis des essais en conditions réelles.

L’identité de l’organisateur est fournie par Sites et contrôlée pour chaque partie. Les accès de personnages sont des clés aléatoires distinctes des QR publics ; aucune clé privée n’est retournée lors d’un scan. Les notes personnelles ne sont pas incluses dans la vue MJ ou les exports. Une clé révoquée cesse de fonctionner.

Les données sont persistées en D1. Les opérations de jeu regroupent vérifications de version, écritures et journal dans un batch atomique. Les formulaires de blessures, compétences, dons et votes réutilisent un identifiant d’action en cas de réessai. Les compteurs d’usage sont persistés indépendamment du journal paginé.

## Limites explicites

Cette version implémente les principes demandés dans un projet Sites distinct. Elle ne constitue pas une copie complète du projet Firebase Murder Engine. Le Master Excel de Murder Engine et ses scénarios ne sont pas importables directement. Les médias immersifs, factions à permissions, prises d’objets par QR, règles conditionnelles complexes et cartes ne sont pas inclus.

Une connexion est requise pour agir. Il n’y a pas de synchronisation hors ligne. Le QR caméra intégré utilise BarcodeDetector si disponible ; un champ de code permet la saisie manuelle. Le QR ne prouve pas techniquement la proximité : la réalisation de la scène reste déclarative.

L’absence de quota dans l’application n’est pas une garantie de capacité infinie. Les tests de pagination avec 123 personnages ne mesurent pas une charge simultanée réelle. Aucun test de charge ou événement réel n’a été exécuté.

## Vérifications

- `node node_modules/typescript/bin/tsc --noEmit`
- `node tests/integration.mjs` : 42 assertions comportementales sur les routes réelles transpilées, avec les migrations réelles dans SQLite et un adaptateur D1 de test. Accès, pagination (123 personnages), PV, doublons, soins, états QR, concurrence, objets, votes, arbitrage, notes privées, annulation atomique, historique et révocation.
- Build Vinext de production via le helper Sites.
- Pas de vérification visuelle dans un navigateur : la capacité de contrôle navigateur requise par l’environnement n’est pas disponible.

Les deux migrations sont uniquement structurelles. Les personnages et parties de test vivent dans une base SQLite éphémère ; aucun scénario fictif n’est préchargé dans la base publiée.
