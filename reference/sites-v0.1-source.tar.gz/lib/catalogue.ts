import type {Skill} from './rules';
const create=(id:string,name:string,category:string,description:string,scene:string,extra:Partial<Skill>={}):Skill=>({id,name,category,description,scene,effect:'ARBITRATION',amount:1,cooldown:0,maxUses:0,allowDown:false,target:'CHARACTER',state:'empoisonné',...extra});
export const CATALOGUE:Skill[]=[
create('premiers-soins','Premiers secours','Soins','Rend 1 PV à un personnage encore conscient.','Jouez la scène de soin définie par le scénario, puis scannez le QR public du blessé.',{effect:'HEAL',amount:1,cooldown:10}),
create('soins-avances','Soins avancés','Soins','Rend 2 PV à un personnage encore conscient.','Interprétez un examen et les soins prévus dans votre scénario.',{effect:'HEAL',amount:2,cooldown:15}),
create('relever','Remise sur pied','Soins','Rend 1 PV, y compris à un personnage hors combat.','Terminez la scène de secours imposée par le scénario avant de valider.',{effect:'HEAL',amount:1,cooldown:20,allowDown:true}),
create('antidote','Antidote','Soins','Retire l’état « empoisonné ».','Présentez l’accessoire d’antidote prévu par le scénario et jouez son administration fictive.',{effect:'CURE',maxUses:2}),
create('diagnostic','Diagnostic','Soins','Demande au MJ des informations sur une blessure ou un état.','Examinez fictivement le personnage et précisez au MJ ce que vous cherchez à savoir.'),
create('stabiliser','Stabilisation','Soins','Demande au MJ la stabilisation d’un personnage sans récupération automatique de PV.','Jouez une scène de premiers secours et sollicitez l’arbitrage.'),
create('crochetage','Crochetage','Discrétion','Ouvre un verrou de jeu en scannant son QR.','Repérez le QR du verrou. Réalisez la scène ou l’épreuve indiquée sur place, puis validez le crochetage.',{target:'FIXTURE',effect:'UNLOCK'}),
create('vol','Vol à la tire','Discrétion','Demande le transfert d’un objet de jeu selon les règles du scénario.','Réalisez la procédure de vol prévue. Le MJ arbitre le résultat et le transfert.'),
create('dissimulation','Dissimulation','Discrétion','Demande qu’un objet de jeu soit dissimulé lors d’une fouille.','Décrivez au MJ l’objet concerné et le dispositif prévu.',{target:'SELF'}),
create('sabotage','Sabotage','Discrétion','Met un équipement de jeu hors service via son QR.','Scannez le QR de l’équipement, jouez la manipulation prévue et validez le sabotage.',{target:'FIXTURE',effect:'SABOTAGE'}),
create('fouille','Fouille spécialisée','Investigation','Demande un indice supplémentaire sur une scène ou un objet.','Examinez la zone de jeu et décrivez précisément votre recherche.',{target:'FREE'}),
create('pistage','Pistage','Investigation','Demande la lecture d’une piste préparée par l’organisation.','Repérez les traces disposées dans le jeu et expliquez votre recherche.',{target:'FREE'}),
create('expertise','Expertise','Investigation','Demande l’identification d’un objet ou d’un document.','Présentez l’objet au MJ et précisez votre domaine d’expertise.',{target:'FREE'}),
create('contacts','Réseau de contacts','Influence','Demande une information auprès d’un contact fictif.','Jouez la prise de contact et formulez une question précise.',{target:'FREE',maxUses:2}),
create('negociation','Négociation','Influence','Demande l’arbitrage d’un avantage commercial prévu par le scénario.','Menez la négociation en personne ; indiquez les termes de l’accord au MJ.'),
create('commandement','Commandement','Influence','Demande l’application d’un effet collectif prévu par le scénario.','Rassemblez les personnes concernées et jouez votre prise de parole.',{target:'FREE'}),
create('reparation','Réparation','Artisanat','Remet en service un équipement saboté via son QR.','Scannez le QR de l’équipement hors service, jouez la réparation et validez.',{target:'FIXTURE',effect:'REPAIR'}),
create('fabrication','Fabrication','Artisanat','Demande la création d’un objet de jeu à partir de ressources.','Présentez les ressources et la recette au MJ. Il valide leur consommation.',{target:'FREE'}),
create('alchimie','Alchimie','Artisanat','Demande la préparation d’une potion fictive prévue au scénario.','Réunissez les ingrédients de jeu puis présentez la recette au MJ.',{target:'FREE'}),
create('protection','Rituel de protection','Surnaturel','Demande un effet de protection défini par le scénario.','Accomplissez le rituel fictif prévu avec la cible.',{maxUses:1}),
];
